
package com.mycompany.herancapokemon;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class MainHerancaPokemon {

    
    public static void main(String[] args) {
        
        String continuar , continuar2 ;
        
        int num , estado , numPos;
        
        Scanner entrada = new Scanner(System.in);
        
        Treinador novoTreinador = new Treinador(); 
        Professor novoProfessor = new Professor();
        
        
        List<Pokemon> pokemons; 
        Pokemon pokemon;
        
        System.out.println("Nome treinador:");
        novoTreinador.setNome( entrada.next()  );
        
        pokemons = new ArrayList<>();
        
               
       do{
        
        System.out.println("Digite uma opção: ");
        
        System.out.println("1) Registrar Pokémon na sua lista");
        
        System.out.println("2) Exibir lista de Pokemons do treinador: ");
        System.out.println("3) Alterar um pokemon da Lista de pokemons registrados:");
        
        System.out.println("4) Verificar atualização de pokedex com o professor expert");
        
       System.out.println("Para ver as últimas notícias pokédex digite 5 ou 6");
        
        System.out.println("5) ver os treinadores com os Pokemons mais poderosos registrados na pokédex");
        
        System.out.println("6) ver os melhores professores pokemons para atualizar sua podedex:");
        
        
        
        num = entrada.nextInt() ;

	switch(num){
	
	case 1:
                        do{
            
                        pokemon = new Pokemon(); 
           
                        System.out.println("Digite pokemon: ");
                        pokemon.setNome( entrada.next()  );
           
                        pokemons.add(pokemon) ;
                        
                    
                        novoTreinador.setPokemons(pokemons);
                        
                        
                        System.out.println("Digite sim para continuar adicionando pokemon na lista?" );
        
                        continuar = entrada.next();
                        
                        }while ( "sim".equals(continuar) || "SIM".equals(continuar) );
                        
                        break;                
        case 2: 
                        novoTreinador.imprimir();
                        
                        System.out.println( "Versão Pokedex: " + novoTreinador.versaoPokedex  );    
                        
                        
                        
			break;
	                
	
        case 3:         
                        
                        
                        for ( int i = 0; i < pokemons.size(); i++ ) { 


                        System.out.println( "Posição: " + (i+1) + " - " + novoTreinador.getPokemons().get(i).getNome() );

        

                        }
        
                        pokemon = new Pokemon(); 
           
                        System.out.println("Digite posição do pokemon para alterar: ");
                        numPos = entrada.nextInt();
                        
                        System.out.println("Digite o nome do pokemon que desaje mudar: ");
                        pokemon.setNome( entrada.next()  );
                        
                        numPos = numPos -1;
                        
                        
                        pokemons.set( numPos , pokemon);
                        
                        
                        
                        
                    
                        novoTreinador.setPokemons(pokemons);
                        
                        
                        break;    
                        
        
        
        
        
        case 4: 
			estado = novoProfessor.checarEstadoPokedex(  novoTreinador.estadopokedex ) ;
                        
                        if ( estado == 0 ) {
              
                        novoTreinador.versaoPokedex = "Atualizada";
                        novoTreinador.estadopokedex = true ;
                        
                        System.out.println("Versão atualizada com sucesso!!");
              
                        } else {
                            
                            System.out.println("Sua versão pokedex já está atualizada");
                        }
			
                        break;
	
	
	
         case 5: 
                        novoTreinador.descricaoPersonagem();
                                                
			break;               
                        
         case 6: 
                        novoProfessor.descricaoPersonagem();
                        
			break;                  
	
        
                        
         default: 
			System.out.print("Numero invalido"); 
                        
         }          
                        
         System.out.println("Digite sim para voltar ao menu?" );
        
         continuar2 = entrada.next();
        
        
        } while ( "sim".equals(continuar2) || "SIM".equals(continuar2) );
        
    }
    
    
}


