
package com.mycompany.herancapokemon;

import java.util.List;

abstract class Pessoa{     // 1        
        
//public class Pessoa {

private String nome;
private String sobrenome;
private String rg;
private String endereco;
private String telefone;
private List <Pokemon> pokemons ;



    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List <Pokemon> getPokemons() {
        return pokemons;
    }

    public void setPokemons(List <Pokemon> pokemons) {
        this.pokemons = pokemons;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
     public void imprimir(){
    
        System.out.println("Nome Treinador:"+ getNome()  );  
        
          for( int x =0; x < getPokemons().size(); x++ ) {
              
              getPokemons().get(x).imprimirPokemon();
              
          }  
     }    
     
    public abstract void descricaoPersonagem();  //2
          
          
    
}
