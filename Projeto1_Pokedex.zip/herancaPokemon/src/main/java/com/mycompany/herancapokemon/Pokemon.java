
package com.mycompany.herancapokemon;


public class Pokemon {
    
    private String nome;
    private String altura;
    private String peso;
    private String poder;
    
    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getPoder() {
        return poder;
    }

    public void setPoder(String poder) {
        this.poder = poder;
    }
  
    public void imprimirPokemon ()  {
    
        System.out.println("Pokemon: " + getNome()  );  
        System.out.println("Altura: " + getAltura () );
        System.out.println("Peso: " + getPeso() );
        System.out.println("Poder: " + getPoder() );
    }
    
}
