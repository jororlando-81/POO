
package com.mycompany.herancapokemon;


public class Professor extends Pessoa{

    public Professor() {
        
        super ();
        
    }

   
  public int checarEstadoPokedex ( boolean estadopokedex  ) {
        
   if ( estadopokedex == true ){
       
       return 1 ;
   
   }else{
       
       return 0 ;
   }
        
  }
      
  public void descricaoPersonagem(){
        
        System.out.println("1- Professor Sicômoro, trabalha num laboratório na cidade Lumiose.");
        System.out.println("2- Professor Kukui, é treinador pokémon e lutador profissional de luta livre.");
        System.out.println("3- Professora juniper, ela foi a primeira professora feminina e se especializa na origem dos pokémon.");
    }
    
  

}