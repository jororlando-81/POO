
package com.mycompany.projectpokedex2.conexao;

public interface EntidadeBase {

    public Integer getId();
}

