
package com.mycompany.herancapokemon;


public class Pokemon {
    
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void imprimirPokemon ()  {
    
        System.out.println("Pokemon: " + getNome()  );  
    
   }
    
    
}
