
package com.mycompany.herancapokemon;


public class Professor extends Pessoa{

    public Professor() {
        
        super ();
        
    }

   
  public int checarEstadoPokedex ( boolean estadopokedex  ) {
        
   if ( estadopokedex == true ){
       
       return 1 ;
   
   }else{
       
       return 0 ;
   }
        
  }  
      
  
  

}