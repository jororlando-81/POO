
package com.mycompany.herancapokemon;


public class Treinador extends Pessoa {
    
    boolean estadopokedex = false;
    
    String versaoPokedex = "Desatualizada"  ;
        
    public Treinador() {
        
        super() ;
            
    }
    
    
    
    
}

