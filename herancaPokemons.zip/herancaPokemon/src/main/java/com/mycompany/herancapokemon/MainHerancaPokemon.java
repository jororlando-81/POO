
package com.mycompany.herancapokemon;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class MainHerancaPokemon {

    
    public static void main(String[] args) {
        
        String continuar ;
        
        int num , estado;
        
        Scanner entrada = new Scanner(System.in);
        
        Treinador novoTreinador = new Treinador(); 
        Professor novoProfessor = new Professor();
        
        
        List<Pokemon> pokemons; 
        Pokemon pokemon;
        
        System.out.println("Nome treinador:");
        novoTreinador.setNome( entrada.next()  );
        
        pokemons = new ArrayList<>();
        
        
        
        
       do{
        
        System.out.println("Digite uma opção: ");
        System.out.println("1) Registrar Pokémon");
        System.out.println("2) Verificar atualização de pokedex com o professor expert");
        System.out.println("3) Exibir os dados do treinador: ");    
	System.out.println("4) ver os treinadores com os Pokemons mais poderosos");
        System.out.println("5) ver os melhores professores pokemons:");
        
        num = entrada.nextInt() ;

	switch(num){
	
	case 1:
                        pokemon = new Pokemon(); 
           
                         System.out.println("Digite pokemon: ");
                         pokemon.setNome( entrada.next()  );
           
                         pokemons.add(pokemon) ;
             
                         novoTreinador.setPokemons(pokemons);
            
			break;
	
	case 2: 
			estado = novoProfessor.checarEstadoPokedex(  novoTreinador.estadopokedex ) ;
                        
                        if ( estado == 0 ) {
              
                        novoTreinador.versaoPokedex = "Atualizada";
                        novoTreinador.estadopokedex = true ;
                        
                        System.out.println("Versão atualizada com sucesso!!");
              
                        } else {
                            
                            System.out.println("Sua versão pokedex já está atualizada");
                        }
			
                        break;
	
	case 3: 
                        novoTreinador.imprimir();
                        
                        System.out.println( "Versão Pokedex: " + novoTreinador.versaoPokedex  );    
                        
                        
                        
			break;
	
         case 4: 
                        novoTreinador.descricaoPersonagem();
                                                
			break;               
                        
         case 5: 
                        novoProfessor.descricaoPersonagem();
                        
			break;                  
	
         default: 
			System.out.print("Numero invalido"); 
                        
         }          
                        
         System.out.println("Digite sim para continuar?" );
        
         continuar = entrada.next();
        
        
        } while ( "sim".equals(continuar) || "SIM".equals(continuar) );
        
    }
    
}
        