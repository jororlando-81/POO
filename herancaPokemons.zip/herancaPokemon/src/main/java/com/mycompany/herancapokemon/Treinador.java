
package com.mycompany.herancapokemon;

public class Treinador extends Pessoa {    
    
    boolean estadopokedex = false;
    
    String versaoPokedex = "Desatualizada"  ;
        
    public Treinador() {
        
        super() ;
            
   }
    
    public void descricaoPersonagem(){
        
        System.out.println("1- Alain, treinador de Charizard 'Fogo Voador'");
        System.out.println("2- Steven, treinador de Metagross 'Aço Psíquico'");
        System.out.println("3- Kaki, treinador de Torturator 'Dragão fogo'");
        
    }
    
    
}

